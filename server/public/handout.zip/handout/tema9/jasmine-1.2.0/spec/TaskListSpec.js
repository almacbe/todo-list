describe("TaskList", function() {
  
  it('adds a new task', function(){
    var taskList = new TaskList();

    /*place here your code*/
   
    expect(taskList.allList().length).toEqual(1);

  });

  it('marks a task as done', function(){

  });

});