(function( window ) {
	var taskList = new TaskList();

	var newTask = document.getElementById('new-todo');

	newTask.addEventListener('blur', function(event){
	});

})( window );