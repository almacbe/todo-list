# Template • [TodoMVC](http://todomvc.com)



## Getting Started

Read the [App Specification](https://github.com/addyosmani/todomvc/wiki/App-Specification) before touching the template.


## Need help?

Feel free to [contact us](https://github.com/sindresorhus) if you have any questions or need help with the template.


## Credit

Created by [Sindre Sorhus](http://sindresorhus.com)