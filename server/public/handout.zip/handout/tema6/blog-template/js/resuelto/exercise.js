function addIcon() {
	var content = document.getElementById('content');
	var posts = content.children;

	for (var i = 0; i < posts.length; i++) {
		var img = document.createElement('img');
		img.src = 'images/blog.png';
		var h1 = posts[i].children[0].children[0];
		h1.appendChild(img);
	}
}

function removeBlogArchive(){
	var archive = document.getElementById('archive');
	archive.parentNode.removeChild(archive);
}

function addBlogRoll() {

	var widget = document.createElement('div');
	widget.className = 'widget';

	var header = _createHeader();
	var content = _createContent();
	widget.appendChild(header);
	widget.appendChild(content);

	var sideBar = document.getElementById('sidebar');
	sideBar.appendChild(widget);
}


function _createHeader() {
	var header = document.createElement('h2');
	header.innerHTML = 'Blog Roll';

	return header;
}

function _createContent() {
	var content = document.createElement('div');
	content.className = 'contentarea';

	var list = document.createElement('ul');
	content.appendChild(list);

	var items = _createItems();
	for(var i = 0; i < items.length; i++){
		content.appendChild(items[i]);
	}

	return content;
}

function _createItems(){
	var items = [];

	var item1 = document.createElement('li');
	var item1Link = document.createElement('a');
	item1Link.href = "#";
	item1Link.innerHTML = 'This is a link';
	item1.appendChild(item1Link);
	items.push(item1);

	return items;
}

/*
<div class = "widget" > < h2 > Blog Archive < /h2>
		<div class="contentarea">
						<ul>
							<li><a href="#">2011</a > < /li><li><a href="#">2012</a > < /li>
							
							<li><a href="#">2010</a > < /li>
							<li><a href="#">2009</a > < /li>
							<li><a href="#">2008</a > < /li>
						</ul > 
		< /div>
</div >

*/