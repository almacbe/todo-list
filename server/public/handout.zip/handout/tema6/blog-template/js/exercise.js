function addIcon() {
	var content = document.getElementById('content');
	
}

function removeBlogArchive(){
	var archive = document.getElementById('archive');
	
}

function addBlogRoll() {

	var widget = document.createElement('div');
}