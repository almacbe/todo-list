
for(var i=1; i < 20; i++){
	console.log(i, 'is', fizzBuzz(i));
}