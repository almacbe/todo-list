var Task = function(taskText){
	
};