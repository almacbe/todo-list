var TaskList = function() {

		this.send = function(task){
			var message = JSON.stringify({task: task.toObject()}); 

			var request = new XMLHttpRequest();
			request.open("POST", 'http://localhost:3000', true);
	
		};

	};

var aTaskList = new TaskList();