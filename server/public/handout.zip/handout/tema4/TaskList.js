
var taskList = [];

var add = function(text){

}

var remove = function(text){
	
}